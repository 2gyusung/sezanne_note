import React from 'react'

const Header = () => {
  return (
    <div>
      <header>Header</header>
      </div>
  )
}

export default Header
