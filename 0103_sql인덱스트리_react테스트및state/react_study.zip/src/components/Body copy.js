import React, { useState } from 'react'

const Body = () => {
  const [num ,setNum] = useState(0);
  const [text, setText] = useState('')
  const [option, setOption] = useState('')
  const onIncrease = () => setNum(num + 1)

   const handleChange = (e) => {
    setText(e.target.value)
   }

  const handleOption = (e) => {
    setOption(e.target.value)
  }


  return (
    <section className='Body'>
      <h1>{num}</h1>
      <button onClick={onIncrease}>+1</button>
      <div className='input'>
        <input 
        type='date'
        value={text} 
        onChange={handleChange}></input>
        <p style={{color: 'lightblue'}}>{text}</p>
        <select value={option}
        onChange={handleOption}>
        <option key={'1번'}>1번</option>
        <option key={'2번'}>2번</option>
        <option key={'3번'}>3번</option>
        </select>
        <p>{option}</p>
      </div>
    </section>
  )
}

export default Body
