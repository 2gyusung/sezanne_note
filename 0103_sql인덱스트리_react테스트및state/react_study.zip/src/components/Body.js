import React, { useState } from 'react'

const Body = () => {
    const [name , setName] = useState('')
    const [gender , setGender] = useState('')
    const [brith , setBirth] = useState('')
    const [bio , setBio] = useState('')

  const onChangeName = (e) => {
    setName(e.target.value)
    console.log(name);
    
  }
  const onChangeGender = (e) => {
    setGender(e.target.value)
    console.log(gender);
  }
  const onChangeBirth = (e) => {
    setBirth(e.target.value)
    console.log(brith);
  }
  const onChangeBio = (e) => {
    setBio(e.target.value)
    console.log(bio);
  }
    
  return (
    <section className='Body'>
      <div>
        <input 
          value={name} 
          onChange={onChangeName} 
          placeholder='이름'
        />
      </div>
      <div>
        <select
        value={gender}
        onChange={onChangeGender}
        >
          <option key={''}></option>
          <option key={'남성'}>남성</option>
          <option key={'여성'}>여성</option>
        </select>
      </div>
      <div>
        <input
        type='date'
        value={brith}
        onChange={onChangeBirth}
        />
      </div>
      <div>
    <textarea
      value={bio}
      onChange={onChangeBio}
    ></textarea>
      </div>
    </section>
  )
}

export default Body
