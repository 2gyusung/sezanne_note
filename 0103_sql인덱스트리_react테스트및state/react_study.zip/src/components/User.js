import React from 'react'

const User = ({name} ) => {
  // console.log('props :', props);
  // const {name} = props
  return (
    <div className='User'>
      User - {name}
    </div>
  )
}

export default User
