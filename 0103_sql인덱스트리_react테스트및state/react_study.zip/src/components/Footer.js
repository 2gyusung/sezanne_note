import React from 'react'

function Footer() {
  return (
    <div>
       <footer>Footer</footer>
    </div>
  )
}

export default Footer
