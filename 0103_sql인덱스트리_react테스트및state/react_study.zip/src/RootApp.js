import Header from './components/Header';
import Body from './components/Body';
import Footer from './components/Footer';
import './RootApp.scss';


export default function RootApp() {
  return (
    <div className='App'>
      <Header/>
      <Body/>
      <Footer/>
    </div>
  )
}