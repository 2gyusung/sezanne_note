import React from 'react'


const Mountain = ({id, name ,address}) => {
  // console.log('출력',id ,name, address);
  
  return (
   <tr>
  <td>{id}</td>
  <td>{name}</td>
  <td>{address}</td>
   </tr>
  )
}

export default Mountain
