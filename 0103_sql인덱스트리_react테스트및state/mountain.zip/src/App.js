
import './App.css';
import Mountain from './components/Mountain';

const Data = [
  {
    id :'01',
    name : '대둔산',
    address : '충청남도 논산시 벌곡면ㆍ금산군 진산면, 전라북도 완주군 운주면'
  },
  {
    id :'02',
    name : '계룡산',
    address : '대전광역시, 충청남도 공주시 계룡면, 논산시 상월면, 계룡시 신도안면'

  },
  {
    id :'03',
    name : '덕숭산',
    address : '충청남도 예산군 덕산면'

  },
  {
    id :'04',
    name : '서대산',
    address : '충청남도 금산군 추부면ㆍ군북면, 충청북도 옥천군 군서면'

  },
  {
    id :'05',
    name : '천태산',
    address : '충청북도 영동군 양산면, 충청남도 금산군 제원면'

  },
  {
    id :'06',
    name : '칠갑산',
    address : '충청남도 청양군 대치면, 정산면, 장평면'

  },
]


function App() {
  return (
    <div className="App">
      <table>
    <thead>
      <tr>
        <th>순번</th>
        <th>이름</th>
        <th>주소</th>
      </tr>
      </thead>
      <tbody>
     {
       Data.map(data=> {
         return <Mountain {...data} key={data}/>
        })
      }
    </tbody>
      </table>
    </div>
  );
}

export default App;
