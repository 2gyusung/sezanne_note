import '../scss/SubMenu.scss'

function SubMenu({menu}) {
return (

  <ul className='gnb'>
 {
   menu.map(menu=>  ( 
     <li key={menu}>{menu}</li>
    ))
  }
  </ul>
  
)
}



export default SubMenu;