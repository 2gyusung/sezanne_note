import '../scss/Header.scss'
import SubMenu from '../components/SubMenu'

const menu = [
  '홈','유니폼','축구화/풋살화','축구용품'
]

const Header = () => {
  return (
    <>
    <header>
      <h1><a href='/'>카포스토어⚽</a></h1>
    </header>
      <SubMenu menu={menu}/>
    </>
  )
}

export default Header