import ProductItem from './ProductItem';
import './Product.scss'
function Product({products}) {
  // console.log('props :', products);
  
  return (
    <article className='Product'>
      <h3>축구 유니폼</h3>
      {
        products.map(product=>  ( 
          <ProductItem product={product} key={product.id}/>
        ))
      }
    </article>
  )
}

export default Product;