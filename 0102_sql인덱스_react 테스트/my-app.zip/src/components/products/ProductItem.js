import './ProductItem.scss'

function ProductItem({product : {product, price , url}}) {
  // console.log('product',product,url,price);
  
  return (
    <div className='item'>
      <img src={url}/>
      <div className='price__info'>
        <p className='title'>{product}</p>
        <p className='price'>{price}<span>원</span></p>
      </div>

    </div>
  );
}
export default ProductItem