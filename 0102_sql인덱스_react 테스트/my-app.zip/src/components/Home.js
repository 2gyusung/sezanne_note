import React  from 'react';

import Product from './products/Product';


const Home = ({products}) => {
  
  return (
   <section>
    <div className='inner'>
      <Product products = {products}/>
    </div>
    </section>
  )
}

export default Home