import Header from './components/Header.js'
import Footer from './components/Footer.js'
import Home from './components/Home.js'
import './App.css';

const productData = [
  {
    id :'product01',
    product : 'AS 코리아 2024 나이키 드라이 스타디움 홈 저지 S/S (FJ4282679)',
    url : 'https://capostoreimg.godohosting.com/store5/NKR/NNKRFJ4282679.jpg',
    price : '103,200'

  },
  {
    id :'product02',
    product : '바이에른 뮌헨 24-25 홈 저지 S/S (IT8511)',
    url : 'https://capostoreimg.godohosting.com/store5/ADR/NADRIT8511.jpg',
    price : '107,100'

  },
  {
    id :'product03',
    product : '레알 마드리드 24-25 홈 저지 S/S (IU5011)',
    url : 'https://capostoreimg.godohosting.com/store5/ADR/detail/NADRIU5011_01.jpg',
    price : '119,000'

  },
  {
    id :'product04',
    product: '맨체스터 시티 24-25 홈 저지 S/S (77507501)',
    url : 'https://capostoreimg.godohosting.com/store5/PMR/detail/NPMR77507501_01.jpg',
    price : '104,490'

  },
  {
    id :'product05',
    product: '아스날 24-25 홈 저지 S/S (IT6141)',
    url : 'https://capostoreimg.godohosting.com/store5/ADR/detail/NADRIT6141_01.jpg',
    price : '107,100'

  },
  {
    id :'product06',
    product: '첼시 24-25 나이키 드라이 스타디움 홈 저지 S/S',
    url : 'https://capostoreimg.godohosting.com/store5/NKR/detail/NNKRFN8779496_01.jpg',
    price : '109,600'

  },
]


function App() {
  return (
    <div className="App">
      <Header/>
      <Home  products = {productData}/>
      <Footer/>
    </div>
  );
}

export default App;
