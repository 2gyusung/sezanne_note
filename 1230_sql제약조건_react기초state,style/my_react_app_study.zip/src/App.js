import Body from './components/Body';
import Footer from './components/Footer';
import Header from './components/Header';
import './scss/App.scss';



function App() {
  const isLoading = false;
  return (
   <>
   <Header/>
   {
    !isLoading ?
   (<Body number={10}/>) :
   (<Footer/>)
   }

   <Footer/>
   </>
  );
}

export default App;
