function Body({number})  {
  let isNumber = 100;
  let num = 100;
  const isValue =false;
  const obj = {
    a : 100,
    b : 10
  }
 
  const isLoading = false;
  const styled = {
    fontSize : '100px',
    color :'#fff',
    backgroundColor :'#000'
  }
 
  return (
    <div className='Body'>
      <h1 style={styled}>body Comp</h1>
      <h1 style={{backgroundColor: '#ccc', color :'#fff'}}>body2 Comp</h1>
      <h2>{isNumber}</h2>
      <h2>{isNumber + num}</h2>
      <h2>{isValue || isNumber + num}</h2>
      <h2>{number}</h2>
      <h2>{`a값은${obj.a}입니다`}</h2>
      <h2>a의 값은 {obj.a}입니다</h2>
      {
        !isLoading ? (<h3>loading...</h3>) : (<h3>bodyContents</h3>)
      }
    </div>
  )
}
export default Body;