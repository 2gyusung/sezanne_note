const Header = () => {
  return (
    <h1>header Comp</h1>
  )
}

export default Header