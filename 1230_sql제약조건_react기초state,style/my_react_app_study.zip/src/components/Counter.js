import { useState } from 'react'

 function Counter({product}) { //{product, count}
  const [counter , setCounter] = useState(10)
  // const {product, count} = props;
 const handleCounter = () => {
  setCounter(counter + 1)
  }
  return (
    <>
    <div className='Counter'>
      <h2>구매 목록</h2>
      <div className='sub'>
      <h3>제품명 : {product}</h3>
      <h3>수량 : {counter}</h3>
      </div>
      <button onClick={handleCounter}>+1</button>
    </div>
    </>
    
  )
}
export default Counter;