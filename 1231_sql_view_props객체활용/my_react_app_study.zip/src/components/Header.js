import './Header.scss'
const Header = () => {
  return (
    <header>
      <h1><a href='/'>Logo.,Ltd</a></h1>
    </header>
  )
}

export default Header