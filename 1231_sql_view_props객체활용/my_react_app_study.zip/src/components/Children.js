function Children({children}) {
  // console.log(props);
  
  return (
    <>
    <h3>Children Comp</h3>
    {children}
    </>
  )
}
export default Children