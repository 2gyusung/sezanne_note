import './ProductItem.scss'

function ProductItem() {
  return (
    <div className='item'>
      <img src='https://thumbnail7.coupangcdn.com/thumbnails/remote/160x160ex/image/vendor_inventory/519d/daee3d367fa4028174883569d0bc584db84f9a0ecd4ed3ef9a8a3681ba4f.jpg'/>
      <div className='price__info'>
        <p className='title'>코마드 여성 기모안감 일자 코듀로이팬츠</p>
        <p className='price'>16,900<span>원</span></p>
      </div>

    </div>
  );
}
export default ProductItem