import ProductItem from './ProductItem';
import './Product.scss'
function Product({products}) {
  console.log('props :', products);
  
  return (
    <article className='Product'>
      <h3>여성 패션</h3>
      <ProductItem/>
      <ProductItem/>
      <ProductItem/>
      <ProductItem/>
    </article>
  )
}

export default Product;