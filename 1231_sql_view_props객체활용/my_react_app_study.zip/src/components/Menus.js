export default function Menus(props) {
  console.log(props);
  
  return (
    <li>{props.item}</li>
  )
}