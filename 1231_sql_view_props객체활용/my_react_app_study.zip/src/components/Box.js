 const Box = (
  {name, age ,eat,favorList, user, handler}
) => {
  // console.log(props);
  // const {name , number} = props;
 
  

  return (
    <h2 onClick={handler} 
    style={ {color: 'orange'}}
    >
     {name}<br/>
     {favorList.length}<br/>
      {age}<br/>
    {user}
      </h2>
  )
}

export default Box;