import './Footer.scss'

export default function Footer() {
  return (
    <footer>
      <h1>Footer comp</h1>
    </footer>
  )
}