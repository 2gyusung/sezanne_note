import React  from 'react';
import './Home.scss'
import Product from '../components/products/Product';


const Home = ({products}) => {
  
  return (
   <section>
    <div className='inner'>
      <Product products = {products}/>
    </div>
    </section>
  )
}

export default Home