import { Component } from 'react';
import './scss/App.scss';

class Counter extends Component {
  constructor(){
    super();
    this.state = {
      number : 50
    }
  }
  handleCounter() {
    this.setState({
      number : this.state.number + 1
    })
  }
  render() {
    return (
      <>
      <h2>items</h2>
      <h3>Counter : {this.props.count}</h3>
      <h3>Counter : {this.state.number}</h3>
      <button onClick={this.handleCounter.bind(this)}>+1</button>
      </>
    )
  }
}

class ClassApp extends Component {
  render(){
    return(
      <>
      <h1>Hello!!</h1>
      <Counter count={100}/>
      </>
    )
  }
}
export default ClassApp;