
import Children from './components/Children';
import Box from './components/Box';
import './scss/App.scss';



const obj = {
  name : 'Gildong',
  age : 100,
  eat : function() {
    console.log(this.name);
    
  },
  favorList : [1,2,3,4,5]
}

const handlerChange = (e) => {
  console.log(e);
  console.log(e.target);
  
}

function App() {


  return (
   <>
   {/* <Header/>
   {
    !isLoading ?
   (<Body number={10}/>) :
   (<Footer/>)
   } */}
   {/* <Box name={'Gildong'} number={100}/> */}
   <Box {...obj}
    user='Good'
     handler={handlerChange}/>
  <Children>
    <div className='Children__container'>
      <p>lorem</p>
    </div>
  </Children>
 
   {/* <Box user = [{...obj}]/> */}
  
   </>
  );
}

export default App;
