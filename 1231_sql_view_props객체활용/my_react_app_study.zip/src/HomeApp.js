import Header from './components/Header'
import Footer from './components/Footer'
import Home from './pages/Home'
import './scss/App.scss'

const productData = [
  {
    product : '코마드 여성 기모안감 일자 코듀로이팬츠 WPT582',
    url : 'https://thumbnail7.coupangcdn.com/thumbnails/remote/160x160ex/image/vendor_inventory/519d/daee3d367fa4028174883569d0bc584db84f9a0ecd4ed3ef9a8a3681ba4f.jpg',
    price : '16,900'

  },
  {
    product : '졸리팜므 더엘라 뜨왈 올리비아백 토트백 여자 데일리백 골프 기저귀 가방',
    url : 'https://thumbnail8.coupangcdn.com/thumbnails/remote/160x160ex/image/vendor_inventory/40f7/3ae2fa5723eab16367aba9a04fefb68ec8d51c0cbea86e1f95344b754f86.jpg',
    price : '15,900'

  },
  {
    product : '엘쏘 여성용 소프트 페이크 퍼 슬리퍼',
    url : 'https://thumbnail8.coupangcdn.com/thumbnails/remote/160x160ex/image/retail/images/337175981568695-5efc942a-7417-4718-9daa-fdce6afb0eb7.jpg',
    price : '17,900'

  },
  {
    product: '파르떼 코듀로이 와이드 밴딩 팬츠 데일리 기모 바지',
    url : 'https://thumbnail10.coupangcdn.com/thumbnails/remote/160x160ex/image/vendor_inventory/a245/7b9628628290f6678cd4864929c15e9c73d7c5f14f4228dd97c38194fae7.jpg',
    price : '18,900'

  },
]

function HomeApp() {
  return (
    <>
    <Header/>
    <Home products = {productData}/>
    <Footer/>
    </>
  )
}
export default HomeApp