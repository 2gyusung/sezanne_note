<template>
<h1>Hello OMDBAPI.com</h1>
<div class="search">
  <input @keydown.enter ="apply" 
  v-model="searchData"
  
  />
</div>
<div class="movies">
  <div class="movies__movie"
  v-for="item in getData"
  :key="item.imdbID">
    <div class="movie__info" 
    :data-id="item.imdbID"
    @click="test"
    >
    <p class="title">{{ item.Title }}</p>
    <p class="type">{{ item.Type }}</p>
    <p class="year">{{ item.Year }}</p>
    </div>
    <div class="movie__poster" 
    :style="`background-image: url(${item.Poster})`"
    @click="infoHandler" 
    :data-id="item.imdbID">
    </div>
  </div>
 </div>
 <div class="btn-group">
  <button @click="nextPage">next...</button>
 </div>
</template>

<script>

import axios from 'axios';
const OMDBAPI = process.env.VUE_APP_OMDbAPI_KEY;


export default {
data() {
  return {
    getData : [],
    searchData : 'Search Data',
    page : 1
  }
},
mounted() {
  const getSearch = async() => {
   const {data} = await axios.get('http://omdbapi.com?apikey=24ec2a28&s=frozen');
   this.getData = data.Search;
  }
  getSearch()
  },
  methods : {
    apply(e) {
      const getSearch = async() => {
        this.searchData = e.target.value;
        const {data} = await axios.get(`http://omdbapi.com?apikey=${OMDBAPI}&s=${this.searchData}`);
        this.getData = data.Search;
  }
  getSearch()
    },
    nextPage() {
      this.page += 1;
      const getSearch = async() => {
        const {data} = await axios.get(`http://omdbapi.com?apikey=24ec2a28&s=${this.searchData}&page=${this.page}`);
        this.getData = await data.Search;
  }
  getSearch()
    },
    infoHandler(e) {
      const imdbID = e.target.dataset.id;
      const getSearch = async() => {
        const {data} = await axios.get(`http://omdbapi.com?apikey=24ec2a28&i=${imdbID}`);
       console.log(data);
       
  }
  getSearch()
}
  }
  
}

</script>

<style lang="scss">
h1 {
  color: lightblue;
  font-size: 30px;
}
.movies {
  display: flex;
  flex-wrap: wrap;
  gap: 30px;
}
.movies__movie {
  box-sizing: border-box;
  transition: .5s;
  padding: 20px;
  background-color: lightgrey;
  .movie__info {
    line-height: 1.5;
    margin-bottom: 20px;
  }
  &:hover {
    border-radius: 50px;
 
  }
  .movie__poster {
    $width: 350;
    width: $width+px;
    height: calc($width  * 3 / 2)+px;
    background-size:cover;
    background-position: center;
  }
}
#root {
 
}
</style>
