import { Store } from '../core/coreMovie';


export default new Store({
  photo : './images/img.jpg',
  name : "GYUSUNG/ LEE GYUSUNG",
  email : '97gyusung@gmail.com',
  blog : 'http://www.naver.com',
  github : 'https://github.com/2gyusung',
  repository : 'http://github.com/vanillajs_movie_app'
})